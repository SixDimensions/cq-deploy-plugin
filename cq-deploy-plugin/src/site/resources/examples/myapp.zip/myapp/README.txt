License
============================

Public Domain

I, the copyright holder of this work, hereby release it into the public domain. This applies worldwide.

In case this is not legally possible, I grant any entity the right to use this work for any purpose, 
without any conditions, unless such conditions are required by law.

Info
============================

This project is an example project using the CQ Deploy plugin to deploy a very simple project to 
Adobe CQ.  To install the project, simply execute: mvn clean install inside the project root directory.

This project can be imported into Eclipse with the m2e plugin.

This project is not meant to be a reference or to demonstrate best practices.